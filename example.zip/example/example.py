################################################################################
# Required Header for all addons
from bottle import route, Bottle, template, TEMPLATE_PATH, debug
import commands

APPDIR = '/app' #os.path.dirname(sys.argv[0])
TEMPLATE_PATH.insert(0, APPDIR +'/addons/'+ str(__name__) +'/views')
app = Bottle()

from cork import Cork
aaa = Cork(APPDIR + '/auth')
d = {}
__version__ = '0.0.1'
osversion = commands.getoutput('uname') + " " + commands.getoutput('uname -r')

d['version'] = __version__
d['osversion'] = osversion

# Enable bottle debug logging - is this even useful?
debug(True)
################################################################################
# Edit the menu dictionary below to match the routes
def menuitems():
    return { 'Example' : { 'Home' : '/', 'Example' : '/example', 'Test' : '/test' } }
    
def describe():
    description = """
    This is an example addon that provide an example framework for building  
    addons. This addon does not provide any functionality.
    """
    return description

################################################################################

from bottle import route, Bottle

app = Bottle()

@app.route('/')
def home():
    return 'success'
    
@app.route('/example')
def example():                     
    return 'example'
    
@app.route('/test')
def test():
    return 'success'
